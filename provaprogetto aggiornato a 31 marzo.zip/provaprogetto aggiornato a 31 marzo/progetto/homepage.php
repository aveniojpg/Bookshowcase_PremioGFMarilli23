<?php

require_once('connection.php');

session_start();

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Homepage</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<body>

    <form action="search.php" method="post">
        <input type="text" name="cerca_post" id="cerca_post" placeholder="Cerca libro" required>
        
        <button type="submit" name="cerca" id="cerca">Cerca</button>
    </form>

    <!-- <table>
  <tr>
    <td>Filter Name</td> -->
    
  </tr>
  <?php
//   foreach (filter_list() as $id =>$filter) {
//     echo '<tr><td>' . $filter . '<input <input type="checkbox" id="filter1" name="filter1" value="filter1">' . '</td></tr>';
//   }
  ?>
<!-- </table> -->

    <a href="homepage.php">HOMEPAGE</a>

    <h1>Questa è la homepage</h1>
    <a href="index.php">
        registrati
    </a>
    <br>
    <a href="login.html">
        accedi
    </a>
    <br>

    <a href="profilo.php">
        Vai al tuo profilo
    </a>

    <br>

    <a href="post.php">
        crea post
    </a>
    <br>
</body>
<?php





// if (isset($_GET['IDpost'])) {
//     $IDpost = $_GET['IDpost'];
//     $sql = "SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post WHERE IDpost = $IDpost";
//     $result = $connessione->query($sql);
//     $row1 = $result->fetch_array(MYSQLI_ASSOC);

//     echo "<div> Titolo: " . $row1["titolo"] . "<br>" .
//         " - ID post: " . $row1["IDpost"] . "<br>" .
//         " - ID utente: " . $row1["uid"] . "<br>" .
//         " - ISBN: " . $row1["isbn"] . "<br>" .
//         " - Condizioni: " . $row1["condizioni"] . "<br>" .
//         " - Prezzo: " . $row1["prezzo"] . " Euro" . "<br>";
//     if ($row1["status"] == 0) {
//         echo " - Status: Attivo </div>" . "<br>";
//     } else {
//         echo " - Status: Sospeso </div>" . "<br>";
//     }

//     echo "<img class='imglibro' src=' uploads/" . $row1["file_url"] . "' . </img>" .
//         "<img class='imglibro' src=' uploadsretro/" . $row1["file_url_retro"] . "' . </img>" . "<br>" .
//         "<a href='boh'>Segnala</a>" . "<br>" .
//         "<a href='homepage.php'>Torna indietro</a>";
// } else {

try {
    foreach ($connessione->query("SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post") as $row) {
        echo "<div> Titolo: " . $row["titolo"] . "<br>" .
            " - ID post: " . $row["IDpost"] . "<br>" .
            " - ID utente: " . $row["uid"] . "<br>" .
            " - ISBN: " . $row["isbn"] . "<br>";
        if ($row["status"] == 0) {
            echo " - Status: Attivo </div>";
        } else {
            echo " - Status: Sospeso </div>";
        }
        echo "<a href='viewlibro.php?IDpost=" . $row["IDpost"] . "'>Vedi post</a></td>";
    }
} catch (PDOException $e) {
    print "Error!: " . $e->getMessage() . "<br/>";
    die();
}
// }



$connessione->close();

?>

</html>