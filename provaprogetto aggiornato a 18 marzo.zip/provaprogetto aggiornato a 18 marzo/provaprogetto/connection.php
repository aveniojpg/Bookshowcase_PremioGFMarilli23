<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$db = "bookshowcase";

$connessione = new mysqli($host, $user, $password, $db);

$sql_create = "CREATE TABLE IF NOT EXISTS utente(
    uid INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(30) NOT NULL,
    usernamne VARCHAR(30) NOT NULL,
    password VARCHAR(30) NOT NULL,
    admin SMALLINT(1) NOT NULL,
    imgprofilo VARCHAR(255)
    )";

if($connessione->query($sql_create) === true){
    $emailadmin = "admin@itisgalileiroma.it";
        $sql_select = "SELECT * FROM utente WHERE email = '$emailadmin'";
        try{
            if ($result = $connessione->query($sql_select)) {
                if ($result->num_rows < 1){

                    $idadmin = 1;
                    $username = "admin";
                    $passwordadmin = 12345;
                    $hashed_password = password_hash($passwordadmin, PASSWORD_DEFAULT);
                    $admin = 1;

                    $sql = 
                    "INSERT INTO utente(uid, email, username, password, admin, imgprofilo) 
                    VALUES ('$idadmin', '$emailadmin', '$username', '$hashed_password', '$admin')";

                    header("Location: homepage.php");
                } else {
                    $em = "Errore inserimento admin";
                    header("Location: register.php?error=$em");
                }
            }
        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";
            die();
        }
}

if ($connessione === FALSE) {
    die("Errore durante la connessione: " . $connessione->connect_error);
}
    



?>