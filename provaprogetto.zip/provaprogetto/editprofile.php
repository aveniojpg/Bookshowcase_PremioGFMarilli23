<?php

require_once "connection.php";
session_start();

$idutente =  $_SESSION["uid"];
$imgprofilo = $_SESSION['imgprofilo'];
$username = $_SESSION['username']

?>



<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Edit profile</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>Modifica il tuo profilo</h1>

    <form action='inserteditprofile.php' method="POST" enctype="multipart/form-data">
        <div>
            <?php


            echo "<div>
            <img class='imglibro' src=' imgprofilo/" . $_SESSION['imgprofilo'] . "' . </img>" .
                "</div>" .
                "<br>";


            ?>
            <input type="file" name="newimgprofilo" id="newimgprofilo" accept=".jpg, .jpeg. png">
        </div>

        <input type="submit" value="Conferma modifiche">


    </form>

    <br>
    <a href="profilo.php">Torna al profilo</a>
    <br>

    <?php

    $connessione->close();
    ?>

</body>

</html>