<?php

require_once "connection.php";

session_start();
if (!isset($_SESSION['loggato']) || $_SESSION['loggato'] != TRUE) {
    header("location: login.html");
    exit;
    // se non si è loggati si viene rimandati alla pagina di login
}

if ($_SESSION['admin'] == 0) {
    header("location: login.html");
    exit;
    

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Admin</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<?php

} else {
    echo "Benvenuto nella pagina amministratore";
    echo "Il tuo id admin è: " . $_SESSION['uid'];

    
}

?>

<div class="container">
    <h1>Pagina di amministrazione</h1>

    <h2>Elenco degli utenti</h2>
    <table>
      <thead>
        <tr>
          <th>ID Utente</th>
          <th>Nome</th>
          <th>Cognome</th>
          <th>Email</th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        <?php
        include_once 'gestione.php';

        $sql = "SELECT * FROM utente";
        $result = mysqli_query($conn, $sql);
        while ($row = mysqli_fetch_assoc($result)) {
        ?>
        <form method="post">
            <?php
            echo "<tr>";
            echo "<td>" . $row["uid"] . "</td>";
            echo "<td>" . $row["username"] . "</td>";
            echo "<td>" . $row["Email"] . "</td>";
            echo "<input type='submit' value='elimina'>";
            echo "</tr>";
            }
            ?>
        </form>
      </tbody>
      <h2>Elenco dei post</h2>
      <table>
        <thead>
          <tr>
            <th>ID Post</th>
            <th>ID Utente</th>
            <th>ISBN</th>
            <th>Titolo</th>
            <th>Descrizione</th>
            <th>Prezzo</th>
            <th>Data di inserimento</th>
            <th>Stato</th>
            <th>immagini</th>
          </tr>
        </thead>
        <tbody>
          <?php
          // Recupera l'elenco dei post dal database
          $query = "SELECT * FROM post";
          $result = mysqli_query($conn, $query);

          while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>";
            echo "<td>" . $row["ID_post"] . "</td>";
            echo "<td>" . $row["ID_utente"] . "</td>";
            echo "<td>" . $row["ISBN"] . "</td>";
            echo "<td>" . $row["titolo"] . "</td>";
            // echo "<td>" . $row["descrizione"] . "</td>";
            echo "<td>" . $row["prezzo"] . "</td>";
            // echo "<td>" . $row["data_inserimento"] . "</td>";
            echo "<td>" . $row["condizioni"] . "</td>";
            echo "<td><img src=' imgprofilo/ " . $row["imgprofilo"] . "'></td>";
            echo "</tr>";
          }
          // Chiude la connessione al database
          mysqli_close($conn);
          ?>
        </tbody>
      </table>

    </table>
  </div>