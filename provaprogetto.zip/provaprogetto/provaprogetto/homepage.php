<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Homepage</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>questa è la homepage</h1>
    <a href="index.php">
        registrati
    </a>
    <br>
    <a href="login.html">
        accedi
    </a>
    <br>
    <a href="post.html">
        crea post
    </a>
    <br>

    <?php

    require_once('connection.php');


    $libro = array('$titolo', '$isbn', '$condizioni', '$prezzo');

    $sql = "SELECT titolo, isbn, condizioni, prezzo FROM libro";
    $result = $connessione->query($sql);



    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "Titolo: " . $row["titolo"] . " - ISBN: " . $row["isbn"] . " - Condizioni " . $row["condizioni"] . " - Prezzo " . $row["prezzo"] . " Euro " . "<br>";
        }
    } else {
        echo "0 libri esistenti";
    }


    $connessione->close();
    ?>

</body>

</html>