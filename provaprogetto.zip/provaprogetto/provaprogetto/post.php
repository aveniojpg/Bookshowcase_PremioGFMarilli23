<?php

require_once('connection.php');

$titolo = $connessione->real_escape_string($_POST['titolo']);
$isbn = $connessione->real_escape_string($_POST['isbn']);
$condizioni = $connessione->real_escape_string($_POST['condizioni']);
$prezzo = $connessione->real_escape_string($_POST['prezzo']);

$sql = "INSERT INTO libro(titolo, isbn, condizioni, prezzo) VALUES('$titolo', '$isbn', '$condizioni', '$prezzo')";

if ($connessione->query($sql) === TRUE) {
    echo "Inserimento avvenuto con successo";
} else {
    echo "Errore durante l'inserimento del libro $sql. " . $connessione->error;
}

?>