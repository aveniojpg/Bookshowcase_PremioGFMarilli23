<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>postcreazione</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>



<body>


    <?php

    if (isset($_GET['error'])) : ?>
        <p><?php echo $_GET['error'] ?> </p>
    <?php endif ?>


    <form action="insert.php" method="POST" enctype="multipart/form-data">

        <span>
            Insert book
        </span>

        <div>
            <input type="text" id="titolo" name="titolo" placeholder="Titolo" required>
        </div>


        <input type="file" id="immagine" name="immagine" required>
        <p><img id="output" width="200" /></p>

        <input type="file" id="immagine2" name="immagine2" required>
        <p><img id="output" width="200" /></p>


        <div>
            <input type="text" id="isbn" name="isbn" placeholder="ISBN" required>
        </div>

        <div>
            <input type="text" id="condizioni" name="condizioni" placeholder="Condizione del libro" required>
        </div>

        <div>
            <input type="text" id="prezzo" name="prezzo" placeholder="Prezzo" required>
        </div>

        <div>
            <input type="submit" id="submit" name="submit" value="submit">
        </div>
    </form>

    <a href="homepage.php">
        Vai alla homepage
    </a>
</body>

</html>