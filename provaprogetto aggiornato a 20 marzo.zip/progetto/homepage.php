<?php

require_once('connection.php');

session_start();

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Homepage</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>questa è la homepage</h1>
    <a href="index.php">
        registrati
    </a>
    <br>
    <a href="login.html">
        accedi
    </a>
    <br>

    <a href="profilo.php">
        Vai al tuo profilo
    </a>

    <br>

    <a href="post.php">
        crea post
    </a>
    <br>
</body>
<?php



if (isset($_GET['IDpost'])) {
    $IDpost = $_GET['IDpost'];
    $sql = "SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post WHERE IDpost = $IDpost";
    $result = $connessione->query($sql);
    $row1 = $result->fetch_array(MYSQLI_ASSOC);
    
    echo "<div> Titolo: " . $row1["titolo"] . "<br>" .
    " - ID post: " . $row1["IDpost"] . "<br>" .
    " - ID utente: " . $row1["uid"] . "<br>" .
    " - ISBN: " . $row1["isbn"] . "<br>" .
    " - Condizioni: " . $row1["condizioni"] . "<br>" .
    " - Prezzo: " . $row1["prezzo"] . " Euro" . "<br>";
    if($row1["status"] == 0) {
        echo " - Status: Attivo </div>" . "<br>";
    } else {
        echo " - Status: Sospeso </div>" . "<br>";
    }
    
    echo "<img class='imglibro' src=' uploads/" . $row1["file_url"] . "' . </img>" .
    "<img class='imglibro' src=' uploadsretro/" . $row1["file_url_retro"] . "' . </img>" . "<br>" .
    "<a href='boh'>Segnala</a>" . "<br>" .
    "<a href='homepage.php'>Torna indietro</a>";;
} else {

    try {
        foreach ($connessione->query("SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post") as $row) {
            echo "<div> Titolo: " . $row["titolo"] . "<br>" .
                " - ID post: " . $row["IDpost"] . "<br>" .
                " - ID utente: " . $row["uid"] . "<br>";
                if ($row["status"] == 0) {
                    echo " - Status: Attivo </div>";
                } else {
                    echo " - Status: Sospeso </div>";
                }
                echo "<a href='homepage.php?IDpost=" . $row["IDpost"] . "'>Vedi post</a></td>";
        }
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
}



$connessione->close();

?>

</html>