<?php

require_once('connection.php');

session_start();

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Homepage</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>questa è la homepage</h1>
    

    <a href="admin.php">
        Vai al tuo profilo
    </a>

    <br>
    <h2>Posts:</h2>
    <br>
</body>
<?php

$listacompleta = true;

if (isset($_GET['IDpost'])) {
    $listacompleta = false;
    $sql = "SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post";
    $result = $connessione->query($sql);
    $row1 = $result->fetch_array(MYSQLI_ASSOC);
    echo "<div> Titolo: " . $row1["titolo"] . "<br>" .
    " - ID post: " . $row1["IDpost"] . "<br>" .
    " - ID utente: " . $row1["uid"] . "<br>" .
    " - ISBN: " . $row1["isbn"] . "<br>" .
    " - Condizioni: " . $row1["condizioni"] . "<br>" .
    " - Prezzo: " . $row1["prezzo"] . " Euro" . "<br>";
    if ($row1["status"] == 0) {
        echo " - Status: Attivo </div>";
    } else {
        echo " - Status: Sospeso </div>";
    }
    echo "<img class='imglibro' src=' uploads/" . $row1["file_url"] . "' . </img>" .
    "<img class='imglibro' src=' uploadsretro/" . $row1["file_url_retro"] . "' . </img>" . "<br>" .
    "<a href='boh'>Segnala</a>" . "<br>" .
    "<a href='homepageadmin.php'>Torna indietro</a>";
} else {

    try {
        foreach ($connessione->query("SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post") as $row) {
            echo "<div> Titolo: " . $row["titolo"] . "<br>" .
            " - ID post: " . $row["IDpost"] . "<br>" .
            " - ID utente: " . $row["uid"] . "<br>";
            if ($row["status"] == 0) {
                echo " - Status: Attivo </div>";
            } else {
                echo " - Status: Sospeso </div>";
            }
            echo "<a href='homepageadmin.php?IDpost=" . $row["IDpost"] . "'>Vedi post</a>";
        }
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }
}
// try {
//     foreach ($connessione->query("SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post") as $row) {
//         echo "<div> Titolo: " . $row["titolo"] . "<br>" .
//             " - ID post: " . $row["IDpost"] . "<br>" .
//             " - ID utente: " . $row["uid"] . "<br>" .
//             " - ISBN: " . $row["isbn"] . "<br>" .
//             " - Condizioni: " . $row["condizioni"] . "<br>" .
//             " - Prezzo: " . $row["prezzo"] . " Euro" . "<br>" .
//             " - Status: " . $row["status"] . "</div>" . "<br>" .
//             "<img class='imglibro' src=' uploads/" . $row["file_url"] . "' . </img>" .
//             "<img class='imglibro' src=' uploadsretro/" . $row["file_url_retro"] . "' . </img>" . "<br>";
//     }
// } catch (PDOException $e) {
//     print "Error!: " . $e->getMessage() . "<br/>";
//     die();
// }




$connessione->close();

?>

</html>