<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$db = "bookshowcase";

$connessione = new mysqli($host, $user, $password, $db);

if($connessione === FALSE){
    die("Errore durante la connessione: " . $connessione->connect_error);
}

?>