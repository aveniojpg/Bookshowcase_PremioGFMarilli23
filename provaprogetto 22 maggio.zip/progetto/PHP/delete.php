<?php

require_once "connection.php";

session_start();

if (isset($_GET['IDpost'])) {
    $IDpost = $_GET['IDpost'];
    
    $updatestatus = mysqli_query($connessione, "DELETE FROM post WHERE IDpost = $IDpost");

    header("Location:../HTML/uploadedbooks.php");
}

if (isset($_GET['uid'])) {
    $uid = $_GET['uid'];
    
    $updatestatus = mysqli_query($connessione, "DELETE FROM utente WHERE uid = $uid");

    header("Location:../HTML/uploadedbooks.php");
}


?>