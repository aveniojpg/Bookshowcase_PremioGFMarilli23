<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$db = "bookshowcase";

$connessione = new mysqli($host, $user, $password, $db);

if($connessione === FALSE){
    die("Errore durante la connessione: " . $connessione->connect_error);
}

// query tabelle di prova
// CREATE TABLE utente (
//   uid INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
//   email varchar(30) NOT NULL,
//   username varchar(30) NOT NULL,
//   password varchar(255) NOT NULL,
//   Anno_scolastico int(6),
//   user_type varchar(10) NOT NULL default 'user',
//   imgprofilo varchar(255)
// );

// CREATE TABLE post (
//   IDpost INT NOT NULL AUTO_INCREMENT,
//   titolo varchar(30) NOT NULL,
//   file_url varbinary(255) NOT NULL,
//   file_url_retro varbinary(255) NOT NULL,
//   ISBN BIGINT NOT NULL,
//   condizioni varchar(30) NOT NULL,
//   prezzo INT(2) NOT NULL,
//   uid INT NOT NULL,
//   PRIMARY KEY (IDpost),
//   status varchar(15) NOT NULL,
//   FOREIGN KEY (uid) REFERENCES utente(uid)
  
// );


?>