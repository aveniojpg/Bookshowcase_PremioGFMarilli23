<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Alexandria:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Alexandria:wght@500&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="https://fonts.googleapis.com/css2?family=Alexandria&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

    <link rel="stylesheet" href="/CSS/admin_table.css">

</head>

<?php
require_once('connection.php');

$query = "SELECT * FROM segnalazioni";
$result = $connessione->query($query);
$row = $result->fetch_array(MYSQLI_ASSOC);
 ?>
<body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

    <a href="admin_home.html" class="adminback">Indietro</a>

    <h2 class="admintitle">Lista segnalazioni</h2>

    <table class="table table-striped table-bordered">
        <thead>
          <tr>
            <th scope="col">ID_Post</th>
            <!-- <th scope="col">ID_Libro</th> -->
            <!-- <th scope="col">Utente segnalatore</th> -->
            <th scope="col">Utente segnalato</th>

            <th scope="col">Descrizione</th>

            
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row"></th>
            <!-- <td>blank</td> -->
            <!-- <td>blank</td> -->
            <td>blank</td>

            <td>

              <!-- Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit architecto ducimus doloremque amet eligendi quasi maxime cupiditate molestiae expedita dignissimos. Reiciendis aperiam fuga vel quos facere nulla ab temporibus voluptates. Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa facere aperiam nam optio consectetur iusto eaque! Dolore cumque, quae recusandae labore minima voluptatibus, et explicabo perspiciatis facere ducimus repellat sit. Lorem ipsum dolor sit amet consectetur adipisicing elit. Sequi reiciendis odit rem eligendi aliquam expedita ad voluptates accusantium. Aut porro excepturi ipsa vero adipisci modi in dicta et necessitatibus laborum. -->
            </td>
          </tr>
          
      
        </tbody>
      </table>


    
</body>
</html>