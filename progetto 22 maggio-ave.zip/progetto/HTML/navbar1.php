<script src="../JS/navbar.js"></script>

<body onload="toggleMenu()">

    
<?php
require_once('../PHP/connection.php');
session_start();
        $uid = $_SESSION['uid'];
        $query = "SELECT * FROM utente WHERE uid = $uid";
        $result = $connessione->query($query);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        ?>
    
    <!-- SEZIONE UPPERBAR  -->
    <div class="upperbar">
        <div class="title">
            <a href="lista.html">Bookshowcase</a>
        </div>
        <div class="searchwrap">
        <input type="search" placeholder="Cerca un libro" class="searchbar">
    </div>
        <div class="navigation">
            <input type="checkbox" class="toggle-menu">
            <div class="hamburger"></div>
            <div class="menu">
                <div class="menucontainer">
                    <a href="profilo.php" class="menurow">
                        <img src="../SRC/pfpwhite.png" alt="">
                        <div>Profilo</div>
                </a>
                <a href="uploadedbooks.html" class="menurow">
                    <img src="../SRC/editwhite.png" alt="">
                    <div>I tuoi annunci</div>
            </a>
            <a href="favbooks.html" class="menurow">
                <img src="../SRC/whiteheart.png" alt="">
                <div>Preferiti</div>
        </a>
        <a href="inserzione.html" class="menurow">
            <img src="../SRC/whiteupload.png" alt="">
            <div>Carica un libro</div>
    </a>
        <a href="home.html" class="menurow">
            <img src="../SRC/redexit.png" alt="" id="exit">
            <div class="exit">Esci</div>
    </a>
                </div>
           
                
            </div>
        </div>
        <div class="desktopmenu">
            
           
            <div class="hovercontainer" onclick="toggleMenu()" id="menudesktop">
            <div class="pfphover">
            <img src="../imgprofilo/<?php echo $row['imgprofilo'] ?>" alt="">
            </div>
            <div class="bottomarrow">
                <img src="/SRC/arrow-button.png" alt="">
            </div>
            <div class="hovermenu" id="dropdown">
                <a  class="line" href="profilo.php">
                <img src="../SRC/profilepic.png" alt="">

                    <div class="hovertext">Profilo</div>
                </a>
                <a  class="line" href="uploadedbooks.html">
                    <img src="../SRC/edit.png" alt="">
                    <div class="hovertext">I tuoi annunci</div>
                </a>
                <a  class="line" href="favbooks.html">
                    <img src="../SRC/heart.png" alt="">
                    <div class="hovertext">Preferiti</div>
                </a>
                <a  class="line" href="home.html">
                    <img src="../SRC/exit.png" alt="">
                    <div class="hovertext exit">Esci</div>
                </a>
            </div>
            </div>
            <a href="inserzione.html">
            <button class="publish">Pubblica un libro</button>
        </a>

        </div>
     </div>
     <div class="mobilesection">
        <input type="search" placeholder="Cerca un libro" class="searchbar">
     </div>
    </body>

   
