<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$db = "bookshowcase";

$connessione = new mysqli($host, $user, $password, $db);

if($connessione === FALSE){
    die("Errore durante la connessione: " . $connessione->connect_error);
}

// query tabelle di prova
// CREATE TABLE utente (
//   uid INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
//   email varchar(30)  NOT NULL,
//   username varchar(30) NOT NULL,
//   password varchar(255) NOT NULL,
//   Anno_scolastico int(6),
//   user_type varchar(10) NOT NULL DEFAULT 'user',
//   imgprofilo varchar(255)
// );

// CREATE TABLE post (
//   IDpost INT NOT NULL AUTO_INCREMENT,
//   titolo varchar(30) NOT NULL,
//   file_url varbinary(255) NOT NULL,
//   file_url_retro varbinary(255) NOT NULL,
//   ISBN BIGINT NOT NULL,
//   condizioni varchar(30) NOT NULL,
//   prezzo INT(2) NOT NULL,
//   materia varchar(10) NOT NULL,
//   status INT(1) NOT NULL DEFAULT '0',
//   num_segnalazioni BIGINT,
//   uid INT NOT NULL,
//   PRIMARY KEY (IDpost),
//   FOREIGN KEY (uid) 
//   REFERENCES utente(uid)
// );

// CREATE TABLE segnalazioni (
//   IDsegnalazione INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
//   descrizione TEXT NOT NULL,
//   status varchar(15) NOT NULL DEFAULT 'in corso',
//   IDpost INT NOT NULL,
//   FOREIGN KEY (IDpost) REFERENCES post(IDpost),
//   uid INT NOT NULL,
//   FOREIGN KEY (uid)
//   REFERENCES utente(uid)
// );


?>