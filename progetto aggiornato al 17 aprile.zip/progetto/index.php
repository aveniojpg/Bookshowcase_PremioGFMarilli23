<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Register</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src='main.js'></script>
</head>

<body>
    <form action="register.php" method="post">
        <h1>Registration</h1>
        <div>
            <input type="text" id="email" name="email" placeholder="Email" required>
        </div>
        <div>
            <input type="text" id="username" name="username" placeholder="username" required>
        </div>
        <div>
            <input type="text" id="password" name="password" placeholder="password" required>
        </div>
        <div>
            <input type="submit" name="submit" value="submit">
        </div>
        <a href="#">password dimenticata</a>
        <br>
        <a href="login.html">sei già registrato</a>
    </form>

</body>

</html>