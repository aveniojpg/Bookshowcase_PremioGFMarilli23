<?php

require_once('connection.php');

session_start();

// var_dump($_SESSION['uid']);

// var_dump($_SESSION['idpost']);

if (isset($_GET['submit'])) {

    $uid = $_SESSION['uid'];
    $segnalazione = $_GET['report'];
    $IDpost = $_SESSION['idpost'];

    // var_dump($uid);
    // var_dump($segnalazione);
    // var_dump($IDpost);

    $segnalazione = $connessione->real_escape_string($_GET['report']);
    $sql = "INSERT INTO segnalazioni (descrizione, IDpost, uid) VALUES('$segnalazione', '$IDpost', '$uid')";


    if ($connessione->query($sql) === TRUE) {
        header("Location:viewlibro.php?IDpost=" . $IDpost);
    } else {
        echo "Errore durante la segnalazione $sql. " . $connessione->error;
    }
}

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Report</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>Pagina di segnalazione</h1>

    <form action="report.php" method="get">
        <input type="text" class="report" name="report" id="report" maxlength="300" required>
        <input type="submit" name="submit" value="Invia">
    </form>

</body>

</html>