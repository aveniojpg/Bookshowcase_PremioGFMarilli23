<?php

require_once('connection.php');

$titolo = $_POST['titolo'];
$isbn = $_POST['isbn'];
$condizioni = $_POST['condizioni'];
$prezzo = $_POST['prezzo'];


if (isset($_POST['submit']) && isset($_FILES['immagine'])) {
    include "connection.php";

    echo "<pre>";
    print_r($_FILES['immagine']);
    echo "</pre>";

    $img_name = $_FILES['immagine']['name'];
    $img_size = $_FILES['immagine']['size'];
    $tmp_name = $_FILES['immagine']['tmp_name'];
    $error = $_FILES['immagine']['error'];

    if ($error === 0) {
        if ($img_size > 1250000) {
            $em = "Sorry, your file is too large.";
            header("Location: post.php?error=$em");
        } else {
            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);

            $allowed_exs = array("jpg", "jpeg", "png");

            if (in_array($img_ex_lc, $allowed_exs)) {
                $new_img_name = uniqid("IMG-", true) . '.' . $img_ex_lc;
                $img_upload_path = 'uploads/' . $new_img_name;
                move_uploaded_file($tmp_name, $img_upload_path);

                // Insert into Database
                $sql =
                "INSERT INTO libro(titolo, file_url, isbn, condizioni, prezzo) VALUES('$titolo', '$new_img_name', '$isbn', '$condizioni', '$prezzo')";
                mysqli_query($connessione, $sql);
                header("Location: homepage.php");
            } else {
                $em = "You can't upload files of this type";
                header("Location: post.php?error=$em");
            }
        }
    } else {
        $em = "unknown error occurred!";
        header("Location: post.php?error=$em");
    }
} else {
    header("Location: post.php");
}

// if ($connessione->query($sql) === TRUE) {
//     echo "Inserimento avvenuto con successo";
// } else {
//     echo "Errore durante l'inserimento del libro $sql. " . $connessione->error;
// }


?>