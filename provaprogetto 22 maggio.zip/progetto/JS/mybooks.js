function openmenu() {
    var menu = document.getElementsByClassName("choicecointainer");
    menu.style='display:block';
}