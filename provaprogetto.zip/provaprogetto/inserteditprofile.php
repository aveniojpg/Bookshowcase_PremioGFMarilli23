<?php

require_once "connection.php";
session_start();

$imgprofilo = $_SESSION['imgprofilo'];
$id_utente = $_SESSION['uid'];


if (isset($_POST['submit']) && isset($_FILES['newimgprofilo'])) {
    include "connection.php";    
        $img_name = $_FILES['newimgprofilo']['name'];
        $img_size = $_FILES['newimgprofilo']['size'];
        $tmp_name = $_FILES['newimgprofilo']['tmp_name'];
        $error = $_FILES['newimgprofilo']['error'];

    if ($error === 0) {
        if ($img_size > 1250000) {
            $em = "Il file è troppo grande";
            header("Location: post.php?error=$em");
        } else {
            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);

            $allowed_exs = array("jpg", "jpeg", "png");

            if (in_array($img_ex_lc, $allowed_exs)) {
                $new_imgprofilo_name = uniqid("IMGprofile-", true) . '.' . $img_ex_lc;
                $imgprofilo_upload_path = 'imgprofilo/' . $new_imgprofilo_name;
                move_uploaded_file($tmp_name, $imgprofilo_upload_path);

                // Update Database
                $sql =
                "UPDATE utente SET imgprofilo = '$new_imgprofilo_name' WHERE uid = $id_utente";
                mysqli_query($connessione, $sql);
                header("Location: profilo.php");
            } else {
                $em = "Formato immagine non supportato";
                header("Location: editprofile.php?error=$em");
            }
        }
    } else {
        $em = "Errore sconosciuto";
        header("Location: editprofile.php?error=$em");
    }
} else {
    header("Location: profilo.php");
}

$connessione->close();
// non funziona
?>
