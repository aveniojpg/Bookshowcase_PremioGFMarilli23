<?php

require_once('connection.php');

session_start();

?>

<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Homepage</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <script src='main.js'></script>
</head>

<body>
    <h1>questa è la homepage</h1>
    <a href="index.php">
        registrati
    </a>
    <br>
    <a href="login.html">
        accedi
    </a>
    <br>

    <a href="profilo.php">
        Vai al tuo profilo
    </a>

    <br>
    
    <a href="post.php">
        crea post
    </a>
    <br>


    <?php
    
    try {
        foreach ($connessione->query("SELECT titolo, file_url, file_url_retro, isbn, condizioni, prezzo FROM post") as $row) {
            echo "<div> Titolo: " . $row["titolo"] . "<br>" .
                // " - ID utente: " . $row["uid"] . "<br>" .
                " - ISBN: " . $row["isbn"] . "<br>" .
                " - Condizioni " . $row["condizioni"] . "<br>" .
                " - Prezzo " . $row["prezzo"] . " Euro </div>" . "<br>" .
                "<img class='imglibro' src=' uploads/" . $row["file_url"] . "' . </img>" .
                "<img class='imglibro' src=' uploadsretro/" . $row["file_url_retro"] . "' . </img>";
        }
    } catch (PDOException $e) {
        print "Error!: " . $e->getMessage() . "<br/>";
        die();
    }



    $connessione->close();

?>

<?php
    // try {
// foreach ($connessione->query("SELECT titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo FROM libro") as $row) {
// echo "<div> Titolo: " . $row["titolo"] . "<br>" .
    // " - ISBN: " . $row["isbn"] . "<br>" .
    // " - Condizioni " . $row["condizioni"] . "<br>" .
    // " - Prezzo " . $row["prezzo"] . " Euro </div>" . "<br>" .
// "<img class='imglibro' src=' uploads/" . $row["file_url"] . "' . </img>" .
// "<img class='imglibro' src=' uploadsretro/" . $row["file_url_retro"] . "' . </img>";
// }
// } catch (PDOException $e) {
// print "Error!: " . $e->getMessage() . "<br />";
// die();
// }
    ?>

</body>


</html>