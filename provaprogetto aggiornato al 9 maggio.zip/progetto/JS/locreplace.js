function locationreplaceupload(){
}