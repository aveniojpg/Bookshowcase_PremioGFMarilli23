<?php

$host = "127.0.0.1";
$user = "root";
$password = "";
$db = "bookshowcase";

$connessione = new mysqli($host, $user, $password, $db);

if($connessione === FALSE){
    die("Errore durante la connessione: " . $connessione->connect_error);
}

$sql_create = "CREATE TABLE utente(
    uid INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(30) NOT NULL,
    usernamne VARCHAR(30) NOT NULL,
    password VARCHAR(30) NOT NULL,
    admin SMALLINT(1) NOT NULL,
    imgprofilo VARCHAR(255)
    )";

    if($connessione->query($sql_create) === true){
        $sql_select = "SELECT * FROM utente WHERE email = '$email'";
        if ($result = $connessione->query($sql_select)) {
            if ($result->num_rows < 1){

                $idadmin = 1;
                $emailadmin = "admin@itisgalileiroma.it";
                $username = "admin";
                $passwordadmin = 12345;
                $hashedpwd = password_hash($passwordadmin, PASSWORD_DEFAULT);
                $admin = 1;

                $sql = 
                "INSERT INTO utente(uid, email, username, password, admin, imgprofilo) 
                VALUES ('$idadmin', '$emailadmin', '$username', '$hashedpwd', '$admin')";

                header("Location: homepage.php");
            } else {
                $em = "Errore inserimento admin";
                header("Location: register.php?error=$em");
            }
        } else {
            $em = "Errore creazione tabella utente";
            header("Location: register.php?error=$em");
        }
    }
        
    


$connessione->close();

?>