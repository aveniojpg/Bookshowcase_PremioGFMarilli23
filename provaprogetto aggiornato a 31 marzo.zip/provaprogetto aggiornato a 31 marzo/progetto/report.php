<?php

require_once('connection.php');

session_start();

    if(isset($_POST['submit'])){

        $uid = $_SESSION['uid'];
        $sql_idpost = "SELECT IDpost FROM post WHERE ";
        $result = $connessione->query($sql_idpost);
        $row = $result->fetch_array(MYSQLI_ASSOC);
        
        $IDpost = $row['IDpost'];
        
        $segnalazione = $connessione->real_escape_string($_POST['report']);
        $sql = "INSERT INTO segnalazioni (descrizione, IDpost, uid) VALUES('$segnalazione', '$idpost', '$uid')";


        if ($connessione->query($sql) === TRUE) {
            echo "Segnalazione inviata con successo";
            header("Location:viewlibro.php?IDpost=" . $row['IDpost']);
        } else {
            echo "Errore durante la segnalazione $sql. " . $connessione->error;
        }
    }

?>
