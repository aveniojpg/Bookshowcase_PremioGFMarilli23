<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>View libro</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='main.css'>
    <script src='main.js'></script>
</head>

<body>
    <?php

    if (isset($_GET['IDpost'])) {
        $IDpost = $_GET['IDpost'];
        $sql = "SELECT IDpost, titolo, uid, file_url, file_url_retro, isbn, condizioni, prezzo, status FROM post WHERE IDpost = $IDpost";
        $result = $connessione->query($sql);
        $row1 = $result->fetch_array(MYSQLI_ASSOC);

        echo "<div> Titolo: " . $row1["titolo"] . "<br>" .
            " - ID post: " . $row1["IDpost"] . "<br>" .
            " - ID utente: " . $row1["uid"] . "<br>" .
            " - ISBN: " . $row1["isbn"] . "<br>" .
            " - Condizioni: " . $row1["condizioni"] . "<br>" .
            " - Prezzo: " . $row1["prezzo"] . " Euro" . "<br>";
        if ($row1["status"] == 0) {
            echo " - Status: Attivo </div>" . "<br>";
        } else {
            echo " - Status: Sospeso </div>" . "<br>";
        }

        echo "<img class='imglibro' src=' uploads/" . $row1["file_url"] . "' . </img>" .
            "<img class='imglibro' src=' uploadsretro/" . $row1["file_url_retro"] . "' . </img>" . "<br>" .
            "<a href='boh'>Segnala</a>" . "<br>" .
            "<a href='homepageadmin.php'>Torna indietro</a>";;
    }


    ?>

</body>

</html>