<?php

if(isset($_POST['elimina'])){
    $sql_delete = "DELETE FROM post WHERE IDpost = ";
    if($connessione->query($sql_delete) === true){
        echo "Riga post eliminata con successo";
        header("Location: homepageadmin.php");
    } else {
        echo "Errore nell'eliminazione della riga: " . $connessione->error;
        header("Location: homepageadmin.php");
    }

}

$connessione->close();

?>