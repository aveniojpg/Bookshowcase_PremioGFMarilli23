<?php

if(isset($_POST['elimina'])){
    $sql_delete = "DELETE FROM utente WHERE uid = $_POST['uid']";
    if($connessione->query($sql_delete) === true){
        echo "Riga utente eliminata con successo";
        header("Location: amministratore.php");
    } else {
        echo "Errore nell'eliminazione della riga: " . $connessione->error;
        header("Location: amministratore.php");
    }

}

$connessione->close();

?>