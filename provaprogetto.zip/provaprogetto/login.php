<?php

require_once('connection.php');

$email = $_POST['email'];
$password = $_POST['password'];
$hashed_password = password_hash($password, PASSWORD_DEFAULT);



if (isset($_POST['login'])) {
	$sql_select = "SELECT * FROM utente WHERE email = '$email'";
	if ($result = $connessione->query($sql_select)) {
		if ($result->num_rows == 1) {
			$row = $result->fetch_array(MYSQLI_ASSOC);
			if (password_verify($password, $row['password'])) {
				session_start();

				$_SESSION['loggato'] = TRUE;
				$_SESSION['username'] = $row['username'];
				$_SESSION['uid'] = $row['uid'];
				$_SESSION['email'] = $row['email'];
				

				header("location: profilo.php");
			} else {
				echo "la password è incorretta";
			}
		} else {
			echo "Non ci sono account associati a questa email";
		}
	} else {
		echo "Errore in fase di login";
	}
	$connessione->close();
}


?>

