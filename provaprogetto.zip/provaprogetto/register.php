<?php

require_once('connection.php');

$email = $connessione->real_escape_string($_POST['email']);
$username = $connessione->real_escape_string($_POST['username']);
$password = $connessione->real_escape_string($_POST['password']);
$hashed_password = password_hash($password, PASSWORD_DEFAULT);
// $imgprofilo = $connessione->real_escape_string($_POST['imgprofilo']);

$sql = "INSERT INTO utente(email, username, password) VALUES('$email', '$username', '$hashed_password')";

if($connessione->query($sql) === TRUE){
    echo "Registrazione avvenuta con successo";
    header("Location:login.html");
}

else{
    echo "Errore durante la registrazione dell'utente $sql. " . $connessione->error;
}

?>